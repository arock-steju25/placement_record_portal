from django.shortcuts import render, redirect, get_object_or_404
from .models import PlacementRecord
from .forms import PlacementRecordForm
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.http import HttpResponse
from django.contrib.auth.models import User

def homepage(request):
    return render(request, 'records/homepage.html')

@login_required
def list_placement_records(request):
    query = request.GET.get('q', '')  # Get search input
    records = PlacementRecord.objects.all()

    if query:
        records = records.filter(student__username__icontains=query)

    return render(request, 'records/record_list.html', {'records': records, 'query': query})

@login_required
def add_placement_record(request):
    if request.method == 'POST':
        form = PlacementRecordForm(request.POST, request.FILES)
        if form.is_valid():
            record = form.save(commit=False)
            record.student = request.user  # Assign current user
            record.save()
            return redirect('records:list_placement_records')
    else:
        form = PlacementRecordForm()
    return render(request, 'records/add_record.html', {'form': form})


def student_login(request):
    return render(request, 'records/student_login.html')  # Make sure the path is correct

def student_interface(request):
    return render(request, "records/student_interface.html")

def student_logout(request):
    logout(request)
    return redirect('records:student_login')

@login_required
def place_record(request):
    records = PlacementRecord.objects.all()
    return render(request, 'records/place_record.html', {'records': records})

@login_required
def submit_placement_record(request):
    if request.method == "POST":
        print("Form received!")  # Debugging step
        print("POST Data:", request.POST)  # Print form data received
        print("FILES Data:", request.FILES)  # Print uploaded files
        
        name = request.POST.get("name")
        department = request.POST.get("department")
        yop = request.POST.get("yop")
        offer_type = request.POST.get("offer_type")
        number_of_offers = request.POST.get("number_of_offers")
        company_name = request.POST.get("company_name")
        proof = request.FILES.get("proof")
        remarks = request.POST.get("remarks")

        print("Extracted values:", name, department, yop, offer_type, number_of_offers, company_name, proof, remarks)

        if not name or not department or not yop or not offer_type or not number_of_offers or not company_name:
            messages.error(request, "All fields are required!")
            return redirect("records:place_record")

        if request.user.is_authenticated:
            try:
                record = PlacementRecord.objects.create(
                    student=request.user, 
                    name=name,
                    department=department,
                    yop=yop,
                    offer_type=offer_type,
                    number_of_offers=number_of_offers,
                    company_name=company_name,
                    proof=proof,
                    remarks=remarks
                )
                record.save()
                print("Record saved:", record)  # Debugging print
                messages.success(request, "Placement record submitted successfully!")
                return redirect("records:placement_report")
            except Exception as e:
                print("Error saving record:", e)
                messages.error(request, f"Error saving record: {e}")
                return redirect("records:place_record")
        else:
            messages.error(request, "You must be logged in to submit a record!")
            return redirect("records:student_login")

    return render(request, "records/place_record.html")

@login_required
def placement_report(request):
    records = PlacementRecord.objects.all()
    print("Records fetched:", records)  # Debugging line
    return render(request, "records/placement_report.html", {"records": records})

def admin_login_view(request):
    return render(request, 'records/admin_login.html')

@login_required
def admin_interface(request):
    records = PlacementRecord.objects.all()  # Fetch all placement records
    return render(request, "records/admin_interface.html", {"records": records})

@login_required
def approve_record(request, record_id):
    record = get_object_or_404(PlacementRecord, id=record_id)
    record.status = "Approved"
    record.remarks = "Approved by Admin"
    record.save()
    messages.success(request, "Record approved successfully!")
    return redirect("records:admin_interface")

@login_required
def reject_record(request, record_id):
    if request.method == "POST":
        record = get_object_or_404(PlacementRecord, id=record_id)
        remark = request.POST.get("remark", "Rejected by Admin")
        record.status = "Rejected"
        record.remarks = remark
        record.save()
        messages.error(request, "Record rejected!")
    return redirect("records:admin_interface")
