from django.contrib import admin
from .models import PlacementRecord

admin.site.register(PlacementRecord)
