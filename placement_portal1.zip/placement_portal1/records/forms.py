from django import forms
from .models import PlacementRecord

class PlacementRecordForm(forms.ModelForm):
    class Meta:
        model = PlacementRecord
        fields = ['name', 'department', 'yop', 'offer_type', 'number_of_offers', 'proof', 'status', 'remarks']
