from django.urls import path
from .views import (
    homepage,
    list_placement_records,
    add_placement_record,
    submit_placement_record,
    placement_report,
    student_login,
    student_interface,
    student_logout,
    place_record,
    admin_login_view,
    admin_interface,
    approve_record,
    reject_record,

)
from django.contrib.auth import views as auth_views

app_name = 'records'

urlpatterns = [
    path('', homepage, name='homepage'),
    path('home/', homepage, name='homepage'),
    path('list/', list_placement_records, name='list_placement_records'),
    path('add/', add_placement_record, name='add_placement_record'),
    path("student_login/", student_login, name="student_login"),
    path("student_interface/", student_interface, name="student_interface"),
    path("student_logout/", student_logout, name="student_logout"),
    path('admin_login/', student_login, name='admin_login'),
    path("place_record/", place_record, name="place_record"),
    path("submit_placement_record/", submit_placement_record, name="submit_placement_record"),
    path("placement_report/", placement_report, name="placement_report"),
    path("login/", auth_views.LoginView.as_view(template_name="records/student_login.html"), name="login"),
    path("logout/", auth_views.LogoutView.as_view(), name="logout"),
    path("admin_interface/", admin_interface, name="admin_interface"),
    path("approve_record/<int:record_id>/", approve_record, name="approve_record"),
    path("reject_record/<int:record_id>/", reject_record, name="reject_record"),
]
