from django.db import models
from django.contrib.auth.models import User

class PlacementRecord(models.Model):
    student = models.ForeignKey(User, on_delete=models.CASCADE)  # Linking to a User
    name = models.CharField(max_length=100)
    department = models.CharField(max_length=100)
    yop = models.IntegerField()  # Year of Passing
    offer_type = models.CharField(max_length=20, choices=[('Job', 'Job'), ('Internship', 'Internship')])
    number_of_offers = models.IntegerField()
    company_name = models.CharField(max_length=100)  # Added company name
    proof = models.FileField(upload_to='proofs/')  # For PDF upload
    status = models.CharField(max_length=20, default='INITIATED')
    remarks = models.TextField(blank=True, null=True)

    def __str__(self):
        return f"{self.name} - {self.company_name}"
